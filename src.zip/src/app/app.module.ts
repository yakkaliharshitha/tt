import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import{Ng2SearchPipeModule} from'ng2-search-filter';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DxcUsersDaoService } from './dxc-users-dao.service';
import { FormsModule } from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import { LoginpageComponent } from './loginpage/loginpage.component';
import { HomepageComponent } from './homepage/homepage.component';
import { RegisterComponent } from './register/register.component';
import { ForgetComponent } from './forget/forget.component';
import { ChangepassComponent } from './changepass/changepass.component';
import { CarComponent } from './car/car.component';
import { GetComponent } from './get/get.component';
import { ProComponent } from './pro/pro.component';
import { AddcartComponent } from './addcart/addcart.component';
import { GetaddrComponent } from './getaddr/getaddr.component';
import { CardComponent } from './card/card.component';
import { UpiComponent } from './upi/upi.component';
import { CodComponent } from './cod/cod.component';
import { CheckoutComponent } from './checkout/checkout.component';
import { CarddetailsComponent } from './carddetails/carddetails.component';
import { UpidetailsComponent } from './upidetails/upidetails.component';
import { SearchComponent } from './search/search.component';


@NgModule({
  declarations: [
    AppComponent,
    LoginpageComponent,
    HomepageComponent,
    RegisterComponent,
    ForgetComponent,
    ChangepassComponent,
    CarComponent,
    GetComponent,
    ProComponent,
    AddcartComponent,
    GetaddrComponent,
    CardComponent,
    UpiComponent,
    CodComponent,
    CheckoutComponent,
    CarddetailsComponent,
    UpidetailsComponent,
    SearchComponent
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    Ng2SearchPipeModule
  ],
  providers: [
    DxcUsersDaoService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }

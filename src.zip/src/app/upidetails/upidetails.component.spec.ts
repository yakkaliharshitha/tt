import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpidetailsComponent } from './upidetails.component';

describe('UpidetailsComponent', () => {
  let component: UpidetailsComponent;
  let fixture: ComponentFixture<UpidetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpidetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UpidetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

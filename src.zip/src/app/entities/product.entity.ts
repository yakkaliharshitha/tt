export class Product {
    id: string;
    vechmodel:String;
    vechtype:String;
    vechbrand:String;
    vechnumber:Number;
    vechcost:String;
    vechimage:String;
    vechcc: String;
    vechmilage:String;
    vechpower:String;

}
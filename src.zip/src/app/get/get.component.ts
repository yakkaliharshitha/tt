import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Address } from 'src/address.model';
import { AddressService } from '../address.service';

@Component({
  selector: 'app-get',
  templateUrl: './get.component.html',
  styleUrls: ['./get.component.css']
})
export class GetComponent implements OnInit {

  constructor(private addserv:AddressService,private router:Router)
  {
  
   
  }
  phno:any
  addr:Address={"phno":"","name":"","doorno":"" ,"city":"","state":""};
  ngOnInit(): void {
  }
  saveaddr()
  {
  
  this.addserv.saveaddress(this.addr).subscribe(
  data=>console.log(data),
  error=>console.log(error)
  );
  this.router.navigate(['getaddr']);
  }
  
  }
  



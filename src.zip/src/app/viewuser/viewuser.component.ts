import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { StoreUser } from '../model/User';
import { HttpClientService } from '../service/http-client.service';

@Component({
  selector: 'app-viewuser',
  templateUrl: './viewuser.component.html',
  styleUrls: ['./viewuser.component.css']
})
export class ViewuserComponent implements OnInit {
  @Input()
  user: StoreUser

  constructor(private httpClientService: HttpClientService,
    private router: Router) { }

  ngOnInit(): void {
  }

}

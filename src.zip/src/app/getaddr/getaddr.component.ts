import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Address } from 'src/address.model';
import { AddressService } from '../address.service';

@Component({
  selector: 'app-getaddr',
  templateUrl: './getaddr.component.html',
  styleUrls: ['./getaddr.component.css']
})
export class GetaddrComponent implements OnInit {
  

  constructor(private daosrv:AddressService,private router:Router) {
   
   }
  
  
  
 
  ngOnInit(): void {
  
 
   
  }
  card()
  {
    this.router.navigate(['card']);
  }
  upi()
  {
    this.router.navigate(['upi']);
  }

cod()
{
  this.router.navigate(['checkout']);
}
  

}

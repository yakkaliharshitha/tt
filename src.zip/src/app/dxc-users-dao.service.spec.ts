import { TestBed } from '@angular/core/testing';

import { DxcUsersDaoService } from './dxc-users-dao.service';

describe('DxcUsersDaoService', () => {
  let service: DxcUsersDaoService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DxcUsersDaoService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

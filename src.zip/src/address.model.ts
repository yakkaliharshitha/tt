export class Address
{
    phno:string;
	name:String;
	doorno:string;
	city:String;
	 state:string;
}


	
	
	
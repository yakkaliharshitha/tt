package com.bootmvctask.bootmvctask.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.metamodel.SetAttribute;
import javax.transaction.Transactional;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.LogicalExpression;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bootmvctask.bootmvctask.model.DxcUsers;

@Component
@Transactional
public class DxcUsersDao {

	@Autowired
	SessionFactory sessionFactory;

	public String saveUser(DxcUsers dxcUsers) {
		System.out.println("in save");
		try {
			Session session = sessionFactory.getCurrentSession();
			session.save(dxcUsers);
			System.out.println("after save");

			return "Successfully user created!!!!";
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			System.out.println("exception");
		}

		return "Sorry cannot create user";

	}
}

	
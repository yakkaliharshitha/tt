package com.bootmvctask.bootmvctask;

import java.util.List;

import javax.persistence.metamodel.SetAttribute;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.bootmvctask.bootmvctask.dao.DxcUsersDao;
import com.bootmvctask.bootmvctask.model.DxcUsers;

@Controller
public class HomeController {

	@Autowired
	DxcUsersDao dao;

	@RequestMapping(value = "/save")
	public String home(Model model) {

		return "home";
	}

	

	@RequestMapping(value = "/regdata")
	public String regdata(Model model, @ModelAttribute DxcUsers dxcUsers) {
		String status = dao.saveUser(dxcUsers);
		model.addAttribute("status", status);
		return "display";
	}

}

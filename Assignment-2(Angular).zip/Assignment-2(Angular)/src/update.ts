export class Studentupdate
{
     firstName:String;
	 lastName:String;
     email:String;
     age:number;
     
}
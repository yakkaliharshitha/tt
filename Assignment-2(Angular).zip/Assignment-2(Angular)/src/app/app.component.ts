import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Student } from 'src/student';
import { Studentupdate } from 'src/update';
import { StudentsService } from './students.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'assign2';

  constructor(private router:Router,private daosrv:StudentsService) { 


  }

  ngOnInit(): void {
  }
  student:Student={"firstName":"","lastName":"","email":"" ,"id":0,"age":0};


  create(){
    this.router.navigate(['create'])
  }
 update(){
  this.router.navigate(['update'])
 }
 delete(){
  this.router.navigate(['delete'])
 }
 getall(){
  this.router.navigate(['all'])
 }

}

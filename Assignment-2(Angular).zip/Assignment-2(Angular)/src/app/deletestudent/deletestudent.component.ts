import { Component, OnInit, SystemJsNgModuleLoader } from '@angular/core';
import { Router } from '@angular/router';
import { Student } from 'src/student';
import { StudentsService } from '../students.service';

@Component({
  selector: 'app-deletestudent',
  templateUrl: './deletestudent.component.html',
  styleUrls: ['./deletestudent.component.css']
})
export class DeletestudentComponent implements OnInit {

  constructor(private router:Router,private daosrv:StudentsService) { }
    id:number

  student:Student={"firstName":"","lastName":"","email":"" ,"id":0,"age":0};



  delete(){
this.daosrv.deleteStudent(this.student.id).subscribe(
  
      data=>console.log(data),
      error=>console.log(error)
      
      );
      alert("Successfully Student Deleted")
   console.log(this.id);
      
      }
      
    
  ngOnInit(): void {
  }


  }

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Student } from 'src/student';
import { StudentsService } from '../students.service';

@Component({
  selector: 'app-getallstudents',
  templateUrl: './getallstudents.component.html',
  styleUrls: ['./getallstudents.component.css']
})
export class GetallstudentsComponent implements OnInit {
  constructor(private router:Router,private daosrv:StudentsService) { }
  
students:Student[]=[];
student:Student={"firstName":"","lastName":"","email":"" ,"id":0,"age":0};

getall(){
  this.daosrv.getAllStudents().subscribe(
    data=>this.students=data,
    error=>console.log(error)
    );
    
    
    console.log('test');
    }
    
 
    
    
    
  


ngOnInit(): void {
} 

}
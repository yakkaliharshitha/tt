import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Student } from 'src/student';
import { Studentupdate } from 'src/update';

@Injectable({
  providedIn: 'root'
})
export class StudentsService {
  constructor(private http:HttpClient) { }
    
    saveStudent(student:Student)
    {
    
     return this.http.post<any>(`http://localhost:2212/savedata`,student); 
    }
    updateStudent(student:Student)
    {
      return this.http.put<any>(`http://localhost:2212/update`,student); 
    }
    
    getAllStudents()
    {
      return this.http.get<Student[]>(`http://localhost:2212/getall`); 
    }

    deleteStudent(id:number){
      return this.http.delete<Student>(`http://localhost:2212/delete/student/${id}`);  

    }

  
}

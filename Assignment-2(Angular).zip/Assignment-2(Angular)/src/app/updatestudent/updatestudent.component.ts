import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Student } from 'src/student';
import { Studentupdate } from 'src/update';
import { StudentsService } from '../students.service';

@Component({
  selector: 'app-updatestudent',
  templateUrl: './updatestudent.component.html',
  styleUrls: ['./updatestudent.component.css']
})
export class UpdatestudentComponent implements OnInit {

  constructor(private router:Router,private daosrv:StudentsService) { 


  }


  student:Student={"firstName":"","lastName":"","email":"" ,"id":0,"age":0};



  updatestudents(){


    this.daosrv.updateStudent(this.student).subscribe(
      data=>console.log(data),
      error=>console.log(error)
      
      );
      alert("Successfully Student Details updated")
      console.log(this.student)
      }
    
  ngOnInit(): void {
  }

 
}

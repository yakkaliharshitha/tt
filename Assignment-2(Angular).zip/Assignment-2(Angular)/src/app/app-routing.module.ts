import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CreatestudentComponent } from './createstudent/createstudent.component';
import { DeletestudentComponent } from './deletestudent/deletestudent.component';
import { GetallstudentsComponent } from './getallstudents/getallstudents.component';
import { UpdatestudentComponent } from './updatestudent/updatestudent.component';

const routes: Routes = [
  {path:'', redirectTo:'login',pathMatch:'full'},
  {path:'create',component:CreatestudentComponent},
  {path:'update',component:UpdatestudentComponent},
  {path:'delete',component:DeletestudentComponent},
  {path:'all',component:GetallstudentsComponent},
  
  

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routing = RouterModule.forRoot(routes);

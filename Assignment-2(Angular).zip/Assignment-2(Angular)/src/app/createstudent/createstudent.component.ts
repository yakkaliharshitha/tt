import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Student } from 'src/student';
import { StudentsService } from '../students.service';

@Component({
  selector: 'app-createstudent',
  templateUrl: './createstudent.component.html',
  styleUrls: ['./createstudent.component.css']
})
export class CreatestudentComponent implements OnInit {

  constructor(private router:Router,private daosrv:StudentsService) { 


  }


  student:Student={"firstName":"","lastName":"","email":"" ,"id":0,"age":0};



  addstudents(){


    this.daosrv.saveStudent(this.student).subscribe(
      data=>console.log(data),
      error=>console.log(error)
      
      );
      alert("Successfully Added Student")
      }
    
  ngOnInit(): void {
  }


  }



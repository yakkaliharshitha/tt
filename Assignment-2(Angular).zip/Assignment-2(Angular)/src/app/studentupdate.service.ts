import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Studentupdate } from 'src/update';

@Injectable({
  providedIn: 'root'
})
export class StudentupdateService {

  constructor(private http:HttpClient) { }
  
  

  

}

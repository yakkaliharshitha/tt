export class Student
{
     firstName:String;
	 lastName:String;
     email:String;
     id:number;
     age:number;
     
     
}
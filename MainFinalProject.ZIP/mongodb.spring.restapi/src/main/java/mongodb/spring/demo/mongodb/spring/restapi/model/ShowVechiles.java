package mongodb.spring.demo.mongodb.spring.restapi.model;

import org.springframework.data.annotation.Id;
import org.springframework.stereotype.Component;

@Component
public class ShowVechiles {
	
	@Id
	int vechid;
	String vechmodel;
    String vechtype;
    String vechbrand;
	int vechnumber;
	String vechcost;
	public int getVechid() {
		return vechid;
	}
	public void setVechid(int vechid) {
		this.vechid = vechid;
	}
	public String getVechmodel() {
		return vechmodel;
	}
	public void setVechmodel(String vechmodel) {
		this.vechmodel = vechmodel;
	}
	public String getVechtype() {
		return vechtype;
	}
	public void setVechtype(String vechtype) {
		this.vechtype = vechtype;
	}
	public String getVechbrand() {
		return vechbrand;
	}
	public void setVechbrand(String vechbrand) {
		this.vechbrand = vechbrand;
	}
	public int getVechnumber() {
		return vechnumber;
	}
	public void setVechnumber(int vechnumber) {
		this.vechnumber = vechnumber;
	}
	public String getVechcost() {
		return vechcost;
	}
	public void setVechcost(String vechcost) {
		this.vechcost = vechcost;
	}
	@Override
	public String toString() {
		return "ShowVechiles [vechid=" + vechid + ", vechmodel=" + vechmodel + ", vechtype=" + vechtype + ", vechbrand="
				+ vechbrand + ", vechnumber=" + vechnumber + ", vechcost=" + vechcost + "]";
	}
	public ShowVechiles(int vechid, String vechmodel, String vechtype, String vechbrand, int vechnumber,
			String vechcost) {
		super();
		this.vechid = vechid;
		this.vechmodel = vechmodel;
		this.vechtype = vechtype;
		this.vechbrand = vechbrand;
		this.vechnumber = vechnumber;
		this.vechcost = vechcost;
	}
	public ShowVechiles() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
	

}

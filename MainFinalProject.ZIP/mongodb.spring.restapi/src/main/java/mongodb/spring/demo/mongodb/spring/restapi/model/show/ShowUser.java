package mongodb.spring.demo.mongodb.spring.restapi.model.show;

import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class ShowUser {
	
	private int user_Id;
	private String user_email;
	private String user_name;
	private String user_password;
	private String user_securityQuestionOne;
	private String user_securityQuestionTwo;
	private String user_answerOne;
	private String user_answerTwo;
	public int getUser_Id() {
		return user_Id;
	}
	public void setUser_Id(int user_Id) {
		this.user_Id = user_Id;
	}
	public String getUser_email() {
		return user_email;
	}
	public void setUser_email(String user_email) {
		this.user_email = user_email;
	}
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String use_rname) {
		this.user_name = use_rname;
	}
	public String getUser_password() {
		return user_password;
	}
	public void setUser_password(String user_password) {
		this.user_password = user_password;
	}
	public String getUser_securityQuestionOne() {
		return user_securityQuestionOne;
	}
	public void setUser_securityQuestionOne(String user_securityQuestionOne) {
		this.user_securityQuestionOne = user_securityQuestionOne;
	}
	public String getUser_securityQuestionTwo() {
		return user_securityQuestionTwo;
	}
	public void setUser_securityQuestionTwo(String user_securityQuestionTwo) {
		this.user_securityQuestionTwo = user_securityQuestionTwo;
	}
	public String getUser_answerOne() {
		return user_answerOne;
	}
	public void setUser_answerOne(String user_answerOne) {
		this.user_answerOne = user_answerOne;
	}
	public String getUser_answerTwo() {
		return user_answerTwo;
	}
	public void setUser_answerTwo(String user_answerTwo) {
		this.user_answerTwo = user_answerTwo;
	}
	public ShowUser(int user_Id, String user_email, String use_rname, String user_password,
			String user_securityQuestionOne, String user_securityQuestionTwo, String user_answerOne,
			String user_answerTwo) {
		super();
		this.user_Id = user_Id;
		this.user_email = user_email;
		this.user_name = use_rname;
		this.user_password = user_password;
		this.user_securityQuestionOne = user_securityQuestionOne;
		this.user_securityQuestionTwo = user_securityQuestionTwo;
		this.user_answerOne = user_answerOne;
		this.user_answerTwo = user_answerTwo;
	}
	public ShowUser() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "ShowUser [user_Id=" + user_Id + ", user_email=" + user_email + ", user_name=" + user_name
				+ ", user_password=" + user_password + ", user_securityQuestionOne=" + user_securityQuestionOne
				+ ", user_securityQuestionTwo=" + user_securityQuestionTwo + ", user_answerOne=" + user_answerOne
				+ ", user_answerTwo=" + user_answerTwo + "]";
	}
	
	
	
	
	

}

package mongodb.spring.demo.mongodb.spring.restapi.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Component;

import mongodb.spring.demo.mongodb.spring.restapi.model.Restaurant;

@Component
public class RestaurantDao {

	
	@Autowired
	MongoTemplate mongoTemplate;


	public Restaurant saveRestaurant(Restaurant restuarant)
	{
	try
	{
	mongoTemplate.save(restuarant);
	return restuarant;

	}
	catch (Exception e) {
	e.printStackTrace();

	}
	return null;

	}


	}



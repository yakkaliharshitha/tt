package mongodb.spring.demo.mongodb.spring.restapi.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class Restaurant {

@Id
String restId;
@Override
public String toString() {
return "Restuarant [restId=" + restId + ", name=" + name + "]";
}
public Restaurant(String restId, String name) {
super();
this.restId = restId;
this.name = name;
}
public String getRestId() {
return restId;
}
public void setRestId(String restId) {
this.restId = restId;
}
public String getName() {
return name;
}
public void setName(String name) {
this.name = name;
}
String name;

public Restaurant() {
// TODO Auto-generated constructor stub
}

}


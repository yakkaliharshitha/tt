package com.finalproject.finalproject.UserDao;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.finalproject.finalproject.Admin.Admin;
import com.finalproject.finalproject.User.NewUser;

@Component
@Transactional
public class UserDao {
	@Autowired
	SessionFactory factory;
	public UserDao() {
		// TODO Auto-generated constructor stub
	}
	public UserDao(SessionFactory factory) {
		super();
		this.factory = factory;
		}
	public String  CreateUser(NewUser newUser){
		try{
		Session session=factory.getCurrentSession();
		session.save(newUser);
		return "Successfully Created Account In Our Portal";
		}
		catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
		}
		return "Cannot Create Account In Our Portal Beacause Data Already Used";
		}
	
	
	
	
	public NewUser getUserInfo(int user_Id) {
		Session session = null;
		NewUser user = null;

		session = factory.getCurrentSession();
		user = session.get(NewUser.class, user_Id);
		System.out.println("User Data : "+user);
		
		return user;
	}
	 
	public NewUser getSecInfo(int user_ID) {
		Session session = null;
		NewUser user = null;
		session = factory.getCurrentSession();
		user = session.get(NewUser.class, user_ID);
		return user;
		
	}

	public void changePassword(String password,int userId) {
		NewUser user = null;
		Session session = null;
		
		user = getSecInfo(userId);
		user.setUser_password(password);

		session = this.factory.getCurrentSession();
		
			session.update(user);
	}
	

	

}

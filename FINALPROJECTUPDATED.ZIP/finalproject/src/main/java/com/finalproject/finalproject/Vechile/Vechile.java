package com.finalproject.finalproject.Vechile;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Vechile {
	
	@Id
	int vid;
	String model;
	String vechile;
	String brand;
	int numberveh;
	public int getVid() {
		return vid;
	}
	public void setVid(int vid) {
		this.vid = vid;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getVechile() {
		return vechile;
	}
	public void setVechile(String vechile) {
		this.vechile = vechile;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public int getNumberveh() {
		return numberveh;
	}
	public void setNumberveh(int numberveh) {
		this.numberveh = numberveh;
	}
	public Vechile(int vid, String model, String vechile, String brand, int numberveh) {
		super();
		this.vid = vid;
		this.model = model;
		this.vechile = vechile;
		this.brand = brand;
		this.numberveh = numberveh;
	}
	@Override
	public String toString() {
		return "VechileDao [vid=" + vid + ", model=" + model + ", vechile=" + vechile + ", brand=" + brand
				+ ", numberveh=" + numberveh + "]";
	}
	public Vechile() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	

}
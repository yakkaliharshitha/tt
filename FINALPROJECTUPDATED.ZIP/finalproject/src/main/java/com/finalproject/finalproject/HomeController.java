package com.finalproject.finalproject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.finalproject.finalproject.User.NewUser;
import com.finalproject.finalproject.Admin.Admin;
import com.finalproject.finalproject.AdminDao.AdminDao;
import com.finalproject.finalproject.UserDao.UserDao;


@Controller
public class HomeController {
	@Autowired
	UserDao dao;
	
	
	@RequestMapping(value="/user")
	public String homing()
	{
	return "home";
	}
	
	
	
	@RequestMapping(value="/Showroom")
	public String home(Model model)
	{
	return "Showroom";
	}
	@RequestMapping(value="/SignUp")
	public String SignUp(Model model)
	{
	return "SignUp";
	}
	
	@GetMapping("data")
	public String display(Model model,@ModelAttribute NewUser newuser)
	{
	String status=dao.CreateUser(newuser);
	model.addAttribute("status",status);
	return "display";
	}
	
	@GetMapping("logging")
	public String getLogg() {
		return "login";
	}
	
	@GetMapping("loginn")
	public String getLogin(@RequestParam("user_ID") int user_ID, @RequestParam("user_FullName") String user_FullName,
			@RequestParam("user_password") String user_password, Model model) {
		//System.out.println("Username : "+username);
		NewUser user = null;

		user = dao.getUserInfo(user_ID);
		
		if (user_FullName.equals(user.getUser_FullName()) && user_password.equals(user.getUser_password())) {
			return "success";
		}

		model.addAttribute("message", "Login Failed Please Enter Valid User Info");
		return "fail";
	}
	
	@GetMapping("/displayLogin")
	public String getLoginInfo() {
		return "userLogin";
	}
	
	
	@GetMapping("/main")
	public String getmain() {
		return "home";
	}
	
	
	@GetMapping("/forgot")
	public String getforgot() {
		return "forgotpassword";
	}
	
	
	
	@GetMapping("/pass")
	public String getSec(@RequestParam("user_ID") int user_ID,@RequestParam("user_SecurityQuestion") String user_SecurityQuestion,
			@RequestParam("user_SecurityAnswer") String user_SecurityAnswer,Model model) {
		NewUser user = null;

		user = dao.getUserInfo(user_ID);
		
		if (user_SecurityQuestion.equals(user.getUser_SecurityQuestion()) && user_SecurityAnswer.equals(user.getUser_SecurityAnswer())) {
			model.addAttribute("user_ID", user_ID);
			return "Changepass";
		}

		model.addAttribute("message", "Login Failed Please Enter Valid User Info");
		
				return "forgotpassword";
		
	}
	
	
	
	
     

	@GetMapping("/changepass")
	public String changpass(@RequestParam ("user_password")String user_password, @RequestParam ("conformPass")String conformPass,@RequestParam("user_ID") int user_ID) {
		//System.out.println("user_ID : "+user_ID);
		if(user_password.equals(conformPass)) {
			dao.changePassword(user_password,user_ID);
			return "changed";
		}
		else {
		return "ChangePass";
		}
}
	
	

	@GetMapping("bike")
	public String showbike()
	{
	return "bike";
	}
	
	

	@GetMapping("car")
	public String showcar()
	{
	return "car";
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}

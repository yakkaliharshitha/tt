package com.finalproject.finalproject.Admin;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Admin {
	
	@Id
	int adminid;
	String adminname;
	String pass;
	String security_questions;
	String security_answers;
	public int getAdminid() {
		return adminid;
	}
	public void setAdminid(int adminid) {
		this.adminid = adminid;
	}
	public String getAdminname() {
		return adminname;
	}
	public void setAdminname(String adminname) {
		this.adminname = adminname;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	public String getSecurity_questions() {
		return security_questions;
	}
	public void setSecurity_questions(String security_questions) {
		this.security_questions = security_questions;
	}
	public String getSecurity_answers() {
		return security_answers;
	}
	public void setSecurity_answers(String security_answers) {
		this.security_answers = security_answers;
	}
	@Override
	public String toString() {
		return "Admin [adminid=" + adminid + ", adminname=" + adminname + ", pass=" + pass + ", security_questions="
				+ security_questions + ", security_answers=" + security_answers + "]";
	}
	public Admin(int adminid, String adminname, String pass, String security_questions, String security_answers) {
		super();
		this.adminid = adminid;
		this.adminname = adminname;
		this.pass = pass;
		this.security_questions = security_questions;
		this.security_answers = security_answers;
	}
	public Admin() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

}
	

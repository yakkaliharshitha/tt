package com.finalproject.finalproject.AdminDao;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.finalproject.finalproject.Admin.Admin;
import com.finalproject.finalproject.User.NewUser;
import com.finalproject.finalproject.Vechile.Vechile;
@Component
@Transactional
public class AdminDao {
	
	@Autowired
	SessionFactory factory;

	public AdminDao(SessionFactory factory) {
		super();
		this.factory = factory;
		}
	
	
	
	public String  CreateUser(Admin admin){
		try{
		Session session=factory.getCurrentSession();
		session.save(admin);
		return "Successfully Created Account !!!!!!!";
		}
		catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
		}
		return " Sorry , Cannot Create Account In Our Portal Beacause Data Already Used";
		}
	
	public Admin getAdminInfo(int adminid) {
		Session session = null;
		Admin ad = null;

		session = factory.getCurrentSession();
		ad = session.get(Admin.class, adminid);
		System.out.println("User Data : "+ad);
		
		return ad;
	}
	 
	public Admin getSecInfo(int adminid) {
		Session session = null;
		Admin admin = null;
		session = factory.getCurrentSession();
		admin = session.get(Admin.class,adminid);
		return admin;
		
	}
	
	public void changePassword(String pass,int adminid) {
		Admin admin = null;
		Session session = null;
		
		admin = getAdminInfo(adminid);
		admin.setPass(pass);

		session = this.factory.getCurrentSession();
		
			session.update(admin);
	}
	

	
	
	
	
	public String insert(Vechile vechile) {
		try{
			Session session=factory.getCurrentSession();
			session.save(vechile);
			return "Successfully Created  !!!!!!!!!";
			}
			catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			}
			return " Sorry , Cannot Create Account In Our Portal Beacause Data Already Used";
			}
	
	
	
	public Vechile updatingbyId(int vid){
		try{
		Session session=factory.getCurrentSession();
		Vechile veh=(Vechile)session.get(Vechile.class,vid);
		return veh;
		}
		catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
		}

		return null;
		}



		public String updateAll(Vechile vechile){
		try{
		Session session=factory.getCurrentSession();
		session.update("vechile",vechile);
		return "Successfully Vechile Details updated";
		}
		catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
		}

		return "Sorry could not update Vechile Details";
		}

	
		public String delete(int vid){
			try
			{

			String hql="delete from Vechile f where f.vid = :vid";
			//System.out.println(name);
			Session session= factory.openSession();
			Query query=(Query) session.createSQLQuery(hql);
			query.setParameter("vid",vid);
			
			    int res=query.executeUpdate();
			   
			if(res>0)
			return "Record is Successfully deleted!!!!";
			}


			catch (Exception e) {
			e.printStackTrace();

			}

			return "Sorry could not delete !!!!!!";
			}

	public List<Vechile> getAll(){

			try{
			Session session=factory.getCurrentSession();
			Criteria crit = session.createCriteria(Vechile.class);
			Query query=session.createQuery("from Vechile ");
			query.executeUpdate();
			ArrayList<Vechile> byAll=(ArrayList<Vechile>) query.list();
			return byAll;

			}
			catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			}
			return null;
			}

	
	
	
	
	
	
	
		
	}
	
	
	
	
	
	
	
	



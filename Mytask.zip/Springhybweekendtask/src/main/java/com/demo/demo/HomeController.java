package com.demo.demo;
import com.demo.demo.dao.*;
import java.text.DateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.demo.demo.dao.PlayerDao;

import com.demo.demo.model.Player;
import com.demo.demo.model.School;
@Controller
public class HomeController {
	
	@Autowired
	PlayerDao dao;
	private int id;



	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home() {
	return "home";
	}

	@RequestMapping(value="/savestud")
	public String savestudent(Model model,@ModelAttribute School school)
	{
	String status=dao.saveSchool(school);
	model.addAttribute("status",status);
	return "displayall";
	}



	/*
	* @RequestMapping(value="/display") public String display(Model
	* model,@ModelAttribute School school) {
	*
	* return "display"; }
	*/

	@RequestMapping(value="/search")
	public String search(Model model,@RequestParam int id)
	{
	List<School> status=dao.getbyId(id);
	//System.out.println(status);
	model.addAttribute("status",status);
	return "displaysearch1";
	}


	@RequestMapping(value="/search1")
	public String search1(Model model,@RequestParam String name)
	{
	List<School> status=dao.getbyname(name);
	//System.out.println(status);
	model.addAttribute("status",status);
	return "displaysearch1";
	}


	@RequestMapping(value="/search2")
	public String search2(Model model,@RequestParam int rollno)
	{
	List<School> status=dao.getbyrollno(rollno);
	//System.out.println(status);
	model.addAttribute("status",status);
	return "displaysearch1";
	}



	@RequestMapping(value="/search3")
	public String search3(Model model,@RequestParam String standard)
	{
	List<School> status=dao.getbystandard(standard);
	//System.out.println(status);
	model.addAttribute("status",status);
	return "displaysearch1";
	}



	@RequestMapping(value="/search4")
	public String search4(Model model,@RequestParam int age)
	{
	List<School> status=dao.getbyage(age);
	//System.out.println(status);
	model.addAttribute("status",status);
	return "displaysearch1";
	}

	@RequestMapping(value="/updatepage")
	public String update()
	{
	return "updatepage";
	}


	@RequestMapping(value="/searchForUpdate")
	public String searchForUpdate(Model model,@RequestParam("id")int id)
	{
     int studid=id;
     this.id=studid;
	School school=dao.updatingbyId(id);
	model.addAttribute(school);
	return "updatepage";
	}



	@RequestMapping(value="/updateData")
	public String updateData(@ModelAttribute School school)
	{
	
	school.setId(id);
	String update=dao.updateSchoolByname(school);
	return "updateFinal";
	}



	@RequestMapping(value="/delete")
	public String delete(Model model,@RequestParam ("name") String name)
	{
	String status=dao.deletebyname(name);
	model.addAttribute("status",status);

	return "displaysearch1";
	}


	@RequestMapping(value="/delete1")
	public String delete1(Model model,@RequestParam ("id") int id)
	{
	String status=dao.deletebyid(id);
	model.addAttribute("status",status);

	return "displaysearch1";
	}






	}
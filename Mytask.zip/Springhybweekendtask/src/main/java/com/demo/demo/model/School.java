package com.demo.demo.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class School {
String name;
@Id
int id;
String  standard;
int rollno;
int age;


public int getId() {
return id;
}
public void setId(int id) {
this.id = id;
}
public String getName() {
return name;
}
public void setName(String name) {
this.name = name;
}

public String getStandard() {
return standard;
}
public void setStandard(String standard) {
this.standard = standard;
}
public int getRollno() {
return rollno;
}
public void setRollno(int rollno) {
this.rollno = rollno;
}


public int getAge() {
return age;
}
public void setAge(int age) {
this.age = age;
}
public School() {
super();
// TODO Auto-generated constructor stub
}
@Override
public String toString() {
return " name=" + name + "     " + "id=" + id + "    "+ " standard=" + standard + "    "+ " rollno=" + rollno + "       "+ " age=" + age+ "  ";
}
public School(String name, int id, String standard, int rollno, int age) {
super();
this.name = name;
this.id = id;
this.standard = standard;
this.rollno = rollno;
this.age = age;
}



}



